# 🤖 Telegram AI Automation Bot

Production-ready Telegram bot with AI chat, GitHub automation, browser control, and file operations.

## ✨ Features

- 🧠 **AI Chat** - Groq API (Llama 3.1) with conversation memory
- 💻 **GitHub** - Create repos, push code, manage files
- 🌐 **Browser** - Playwright screenshots, scraping
- 📝 **Files** - Read/write local project files
- 🧩 **Tasks** - AI plans and executes multi-step tasks

## 🚀 Quick Start

### 1. Install
```bash
git clone <your-repo>
cd telegram-ai-bot
npm install
npx playwright install chromium
```

### 2. Configure
```bash
cp .env.example .env
nano .env
```

Add your keys:
```
BOT_TOKEN=your_telegram_bot_token
GROQ_API_KEY=your_groq_key
GITHUB_TOKEN=your_github_token
```

### 3. Run
```bash
npm start
```

## 📱 Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome message |
| `/chat <msg>` | Talk to AI |
| `/clear` | Clear history |
| `/github create <name>` | Create repo |
| `/github files <repo>` | List files |
| `/github read <repo> <file>` | Read file |
| `/browser open <url>` | Open website |
| `/browser screenshot` | Take screenshot |
| `/browser scrape <url>` | Get page text |
| `/tasks` | View tasks |
| `/status` | System status |

## 🏗️ Architecture

```
┌─────────┐  ┌─────────┐  ┌─────────┐
│   AI    │  │  GitHub │  │ Browser │
│ (Groq)  │  │(Octokit)│  │(Playw.) │
└────┬────┘  └────┬────┘  └────┬────┘
     └─────────────┴─────────────┘
                   │
            ┌──────┴──────┐
            │   Commands  │
            │  (Telegraf) │
            └──────┬──────┘
                   │
            ┌──────┴──────┐
            │    JSON     │
            │   Memory    │
            └─────────────┘
```

## 🚂 Railway Deploy

1. Push code to GitHub
2. Go to [railway.app](https://railway.app)
3. New Project → Deploy from GitHub repo
4. Add environment variables in Railway dashboard
5. Done! Bot auto-deploys.

## 🖥️ VPS Deploy

```bash
# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs git

# Clone and setup
git clone <repo>
cd telegram-ai-bot
npm install
npx playwright install chromium

# PM2 for 24/7
npm install -g pm2
pm2 start index.js --name telegram-bot
pm2 save
pm2 startup
```

## 🔧 Environment Variables

| Variable | Required | Source |
|----------|----------|--------|
| `BOT_TOKEN` | Yes | @BotFather |
| `GROQ_API_KEY` | Yes | console.groq.com |
| `GITHUB_TOKEN` | No | github.com/settings/tokens |
| `PORT` | No | Default: 3000 |
| `NODE_ENV` | No | production/development |

## 📝 License

MIT
