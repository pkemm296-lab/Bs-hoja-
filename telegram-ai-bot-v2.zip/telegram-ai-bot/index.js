/**
 * Telegram AI Automation Bot - Main Entry
 * Production-ready Node.js bot with AI, GitHub, Browser automation
 */

require('dotenv').config();
const express = require('express');
const config = require('./config');
const logger = require('./utils/logger');
const ai = require('./ai');
const bot = require('./bot');
const github = require('./github');
const browser = require('./browser');
const commands = require('./commands');

class TelegramAIBot {
  constructor() {
    this.app = express();
    this.isRunning = false;
  }

  async initialize() {
    try {
      logger.info('🚀 Starting Telegram AI Bot...');

      // Initialize modules
      await ai.initialize();
      await github.initialize();
      await browser.initialize();

      // Setup Express
      this.app.use(express.json());
      this.app.get('/health', (req, res) => {
        res.json({
          status: 'healthy',
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          ai: ai.isReady(),
          github: github.isReady(),
          browser: browser.isReady()
        });
      });

      // Setup Telegram bot
      const botInstance = bot.getBot();
      if (botInstance) {
        await commands.register(botInstance);
      }

      logger.info('✅ All systems ready');
      return true;
    } catch (error) {
      logger.error('Initialization failed:', error.message);
      return false;
    }
  }

  async start() {
    try {
      // Start Express server
      this.app.listen(config.PORT, () => {
        logger.info(`Express server on port ${config.PORT}`);
      });

      // Start Telegram bot
      const started = await bot.start();
      this.isRunning = started;

      if (started) {
        logger.info('🤖 Bot is online!');
      }

      // Graceful shutdown
      process.once('SIGINT', () => this.shutdown());
      process.once('SIGTERM', () => this.shutdown());

      return started;
    } catch (error) {
      logger.error('Start failed:', error.message);
      return false;
    }
  }

  async shutdown() {
    logger.info('🛑 Shutting down...');
    this.isRunning = false;
    await bot.stop();
    await browser.cleanup();
    logger.info('👋 Bot stopped');
    process.exit(0);
  }
}

// Start
const app = new TelegramAIBot();
app.initialize().then(ok => {
  if (ok) app.start();
  else {
    logger.error('Failed to initialize. Check your .env file.');
    process.exit(1);
  }
});

module.exports = app;
