/**
 * AI Engine - Groq API Integration
 */

const Groq = require('groq-sdk');
const config = require('../config');
const logger = require('../utils/logger');
const memory = require('../memory');
const Helpers = require('../utils/helpers');

class AIEngine {
  constructor() {
    this.client = null;
    this.ready = false;
  }

  async initialize() {
    try {
      if (!config.GROQ_API_KEY || config.GROQ_API_KEY === 'ADD_LATER') {
        logger.warn('GROQ_API_KEY not set. AI features disabled.');
        return false;
      }
      this.client = new Groq({ apiKey: config.GROQ_API_KEY });
      this.ready = true;
      logger.info('AI Engine ready');
      return true;
    } catch (error) {
      logger.error('AI init failed:', error.message);
      return false;
    }
  }

  isReady() {
    return this.ready;
  }

  getSystemPrompt() {
    return `You are an advanced AI automation assistant in a Telegram bot. You help users with:
- Writing code and creating projects
- GitHub repository management
- Web browsing and data extraction
- File operations and project scaffolding
- Task planning and execution

Current date: ${new Date().toISOString().split('T')[0]}
Respond naturally and helpfully.`;
  }

  async chat(userId, message) {
    if (!this.ready) {
      return { type: 'error', content: 'AI engine not initialized. Set GROQ_API_KEY.' };
    }

    try {
      const history = memory.getConversation(userId, config.MAX_CONTEXT_MESSAGES);
      const memories = memory.getUserMemories(userId);

      const messages = [
        { role: 'system', content: this.getSystemPrompt() },
        ...this.formatMemories(memories),
        ...history,
        { role: 'user', content: message }
      ];

      // Check if task request
      const isTask = this.isTaskRequest(message);

      if (isTask) {
        return await this.planTask(userId, message, messages);
      }

      // Regular chat
      const completion = await this.client.chat.completions.create({
        model: config.AI_MODEL,
        messages,
        temperature: config.AI_TEMPERATURE,
        max_tokens: config.AI_MAX_TOKENS
      });

      const response = completion.choices[0]?.message?.content || 'No response.';
      memory.saveMessage(userId, 'user', message);
      memory.saveMessage(userId, 'assistant', response);

      return { type: 'chat', content: response };
    } catch (error) {
      logger.error('AI chat error:', error.message);
      return { type: 'error', content: `Error: ${error.message}` };
    }
  }

  isTaskRequest(message) {
    const keywords = ['create', 'build', 'deploy', 'setup', 'generate', 'make', 'code', 
      'write', 'fix', 'clone', 'push', 'commit', 'scrape', 'download', 'project'];
    const lower = message.toLowerCase();
    return keywords.some(k => lower.includes(k)) && lower.length > 15;
  }

  async planTask(userId, message, contextMessages) {
    try {
      const planPrompt = `The user wants to perform a task. Create a simple step-by-step plan.

User: "${message}"

Return ONLY a JSON object like this:
{
  "taskType": "github|browser|file|mixed",
  "description": "what to do",
  "steps": [
    {"id": 1, "action": "description", "tool": "github|browser|file|ai"}
  ]
}`;

      const completion = await this.client.chat.completions.create({
        model: config.AI_MODEL,
        messages: [...contextMessages.slice(0, -1), { role: 'user', content: planPrompt }],
        temperature: 0.3,
        max_tokens: 2000
      });

      let plan;
      try {
        const text = completion.choices[0].message.content;
        const match = text.match(/\{[\s\S]*\}/);
        plan = JSON.parse(match ? match[0] : text);
      } catch {
        plan = { taskType: 'mixed', description: message, steps: [{ id: 1, action: message, tool: 'ai' }] };
      }

      const taskId = Helpers.generateId();
      const task = {
        taskId,
        userId,
        type: plan.taskType,
        status: 'pending',
        description: plan.description,
        steps: plan.steps,
        currentStep: 0,
        createdAt: Date.now()
      };

      memory.saveTask(task);

      return {
        type: 'task',
        taskId,
        plan,
        message: `📋 **Task Plan**\n\n**${plan.description}**\n\nSteps:\n${plan.steps.map((s, i) => `${i + 1}. ${s.action}`).join('\n')}\n\nReply **yes** to execute.`
      };
    } catch (error) {
      return { type: 'error', content: `Planning failed: ${error.message}` };
    }
  }

  async executeStep(userId, step, context = {}) {
    try {
      const prompt = `Execute this step and report result concisely:\n\nStep: ${step.action}\nTool: ${step.tool}\nContext: ${JSON.stringify(context)}\n\nWhat did you do? What was the result?`;

      const completion = await this.client.chat.completions.create({
        model: config.AI_MODEL,
        messages: [
          { role: 'system', content: this.getSystemPrompt() },
          { role: 'user', content: prompt }
        ],
        temperature: 0.5,
        max_tokens: 1500
      });

      return {
        success: true,
        result: completion.choices[0].message.content
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  formatMemories(memories) {
    if (!memories || Object.keys(memories).length === 0) return [];
    const text = Object.entries(memories).map(([k, v]) => `${k}: ${v}`).join('\n');
    return [{ role: 'system', content: `User info:\n${text}` }];
  }

  async generateCode(prompt, language = 'javascript') {
    try {
      const codePrompt = `Generate ${language} code for:\n${prompt}\n\nReturn ONLY code in markdown block.`;
      const completion = await this.client.chat.completions.create({
        model: config.AI_MODEL,
        messages: [{ role: 'user', content: codePrompt }],
        temperature: 0.2,
        max_tokens: config.AI_MAX_TOKENS
      });

      const response = completion.choices[0].message.content;
      const match = response.match(/```(?:\w+)?\n([\s\S]*?)```/);
      return { code: match ? match[1].trim() : response.trim() };
    } catch (error) {
      return { error: error.message };
    }
  }
}

module.exports = new AIEngine();
