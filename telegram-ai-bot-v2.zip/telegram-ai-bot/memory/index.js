/**
 * JSON File-based Memory System
 * No database required - uses local JSON files
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class MemorySystem {
  constructor() {
    this.memoryDir = path.resolve(config.MEMORY_DIR);
    this.chatsFile = path.join(this.memoryDir, 'chats.json');
    this.tasksFile = path.join(this.memoryDir, 'tasks.json');
    this.ensureFiles();
  }

  ensureFiles() {
    if (!fs.existsSync(this.memoryDir)) {
      fs.mkdirSync(this.memoryDir, { recursive: true });
    }
    if (!fs.existsSync(this.chatsFile)) {
      fs.writeFileSync(this.chatsFile, '{}');
    }
    if (!fs.existsSync(this.tasksFile)) {
      fs.writeFileSync(this.tasksFile, '{}');
    }
  }

  readJson(file) {
    try {
      const data = fs.readFileSync(file, 'utf8');
      return Helpers.safeJsonParse(data, {});
    } catch {
      return {};
    }
  }

  writeJson(file, data) {
    try {
      fs.writeFileSync(file, JSON.stringify(data, null, 2));
      return true;
    } catch (err) {
      logger.error('Failed to write memory file:', err.message);
      return false;
    }
  }

  // ===== CHAT MEMORY =====

  saveMessage(userId, role, content) {
    const chats = this.readJson(this.chatsFile);
    if (!chats[userId]) chats[userId] = [];

    chats[userId].push({
      role,
      content,
      timestamp: Date.now()
    });

    // Keep only last 50 messages
    if (chats[userId].length > 50) {
      chats[userId] = chats[userId].slice(-50);
    }

    this.writeJson(this.chatsFile, chats);
  }

  getConversation(userId, limit = 20) {
    const chats = this.readJson(this.chatsFile);
    const messages = chats[userId] || [];
    return messages.slice(-limit).map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }

  clearConversation(userId) {
    const chats = this.readJson(this.chatsFile);
    delete chats[userId];
    this.writeJson(this.chatsFile, chats);
    logger.info(`Cleared conversation for user ${userId}`);
  }

  // ===== TASK MEMORY =====

  saveTask(task) {
    const tasks = this.readJson(this.tasksFile);
    tasks[task.taskId] = {
      ...task,
      updatedAt: Date.now()
    };
    this.writeJson(this.tasksFile, tasks);
    return task;
  }

  getTask(taskId) {
    const tasks = this.readJson(this.tasksFile);
    return tasks[taskId] || null;
  }

  getUserTasks(userId) {
    const tasks = this.readJson(this.tasksFile);
    return Object.values(tasks).filter(t => t.userId === userId);
  }

  updateTask(taskId, updates) {
    const tasks = this.readJson(this.tasksFile);
    if (tasks[taskId]) {
      tasks[taskId] = { ...tasks[taskId], ...updates, updatedAt: Date.now() };
      this.writeJson(this.tasksFile, tasks);
    }
    return tasks[taskId] || null;
  }

  // ===== USER MEMORY (extracted from chats) =====

  saveUserMemory(userId, key, value) {
    const chats = this.readJson(this.chatsFile);
    if (!chats._memories) chats._memories = {};
    if (!chats._memories[userId]) chats._memories[userId] = {};
    chats._memories[userId][key] = value;
    this.writeJson(this.chatsFile, chats);
  }

  getUserMemories(userId) {
    const chats = this.readJson(this.chatsFile);
    return (chats._memories && chats._memories[userId]) || {};
  }
}

module.exports = new MemorySystem();
