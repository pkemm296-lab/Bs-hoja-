/**
 * Configuration Module
 */

require('dotenv').config();

const config = {
  BOT_TOKEN: process.env.BOT_TOKEN,
  GROQ_API_KEY: process.env.GROQ_API_KEY,
  GITHUB_TOKEN: process.env.GITHUB_TOKEN,

  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: parseInt(process.env.PORT) || 3000,

  ADMIN_IDS: process.env.ADMIN_IDS 
    ? process.env.ADMIN_IDS.split(',').map(id => id.trim()) 
    : [],

  AI_MODEL: process.env.AI_MODEL || 'llama-3.1-70b-versatile',
  AI_TEMPERATURE: parseFloat(process.env.AI_TEMPERATURE) || 0.7,
  AI_MAX_TOKENS: parseInt(process.env.AI_MAX_TOKENS) || 4096,

  BROWSER_HEADLESS: process.env.BROWSER_HEADLESS !== 'false',

  MEMORY_DIR: process.env.MEMORY_DIR || './memory',
  LOGS_DIR: process.env.LOGS_DIR || './logs',

  MAX_MESSAGE_LENGTH: 4000,
  MAX_CONTEXT_MESSAGES: 20
};

module.exports = config;
