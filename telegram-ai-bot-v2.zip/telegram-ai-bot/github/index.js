/**
 * GitHub Automation - Octokit REST API
 */

const { Octokit } = require('@octokit/rest');
const config = require('../config');
const logger = require('../utils/logger');

class GitHubAutomation {
  constructor() {
    this.octokit = null;
    this.ready = false;
    this.username = null;
  }

  async initialize() {
    try {
      if (!config.GITHUB_TOKEN || config.GITHUB_TOKEN === 'ADD_LATER') {
        logger.warn('GITHUB_TOKEN not set. GitHub features disabled.');
        return false;
      }
      this.octokit = new Octokit({ auth: config.GITHUB_TOKEN });
      const { data: user } = await this.octokit.users.getAuthenticated();
      this.username = user.login;
      this.ready = true;
      logger.info(`GitHub ready (user: ${this.username})`);
      return true;
    } catch (error) {
      logger.error('GitHub init failed:', error.message);
      return false;
    }
  }

  isReady() {
    return this.ready;
  }

  async createRepository(name, description = '', isPrivate = false) {
    try {
      logger.info(`Creating repo: ${name}`);
      const { data: repo } = await this.octokit.repos.createForAuthenticatedUser({
        name,
        description,
        private: isPrivate,
        auto_init: true
      });
      return { success: true, url: repo.html_url, fullName: repo.full_name };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async writeFile(repoName, path, content, message = 'Update file') {
    try {
      const [owner, repo] = repoName.includes('/') ? repoName.split('/') : [this.username, repoName];

      let sha = null;
      try {
        const { data } = await this.octokit.repos.getContent({ owner, repo, path });
        sha = data.sha;
      } catch {
        // File doesn't exist
      }

      const params = { owner, repo, path, message, content: Buffer.from(content).toString('base64') };
      if (sha) params.sha = sha;

      const { data } = await this.octokit.repos.createOrUpdateFileContents(params);
      return { success: true, sha: data.content.sha };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async readFile(repoName, path) {
    try {
      const [owner, repo] = repoName.includes('/') ? repoName.split('/') : [this.username, repoName];
      const { data } = await this.octokit.repos.getContent({ owner, repo, path });
      if (data.type !== 'file') return { success: false, error: 'Not a file' };
      return { success: true, content: Buffer.from(data.content, 'base64').toString('utf8') };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async listContents(repoName, path = '') {
    try {
      const [owner, repo] = repoName.includes('/') ? repoName.split('/') : [this.username, repoName];
      const { data } = await this.octokit.repos.getContent({ owner, repo, path });
      const items = Array.isArray(data) ? data : [data];
      return { success: true, items: items.map(i => ({ name: i.name, type: i.type, path: i.path })) };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async deleteFile(repoName, path, message = 'Delete file') {
    try {
      const [owner, repo] = repoName.includes('/') ? repoName.split('/') : [this.username, repoName];
      const { data: fileData } = await this.octokit.repos.getContent({ owner, repo, path });
      await this.octokit.repos.deleteFile({ owner, repo, path, message, sha: fileData.sha });
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async commitFiles(repoName, files, message = 'Commit files') {
    try {
      const [owner, repo] = repoName.includes('/') ? repoName.split('/') : [this.username, repoName];

      const { data: refData } = await this.octokit.git.getRef({ owner, repo, ref: 'heads/main' });
      const currentCommitSha = refData.object.sha;

      const { data: commitData } = await this.octokit.git.getCommit({ owner, repo, commit_sha: currentCommitSha });

      const treeItems = [];
      for (const file of files) {
        const { data: blobData } = await this.octokit.git.createBlob({
          owner, repo, content: Buffer.from(file.content).toString('base64'), encoding: 'base64'
        });
        treeItems.push({ path: file.path, mode: '100644', type: 'blob', sha: blobData.sha });
      }

      const { data: treeData } = await this.octokit.git.createTree({
        owner, repo, base_tree: commitData.tree.sha, tree: treeItems
      });

      const { data: newCommit } = await this.octokit.git.createCommit({
        owner, repo, message, tree: treeData.sha, parents: [currentCommitSha]
      });

      await this.octokit.git.updateRef({ owner, repo, ref: 'heads/main', sha: newCommit.sha });
      return { success: true, commitSha: newCommit.sha };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async generateProject(repoName, structure, options = {}) {
    try {
      const repoResult = await this.createRepository(repoName, options.description, options.isPrivate);
      if (!repoResult.success) return repoResult;

      const files = Object.entries(structure).map(([path, content]) => ({ path, content }));
      const commitResult = await this.commitFiles(repoName, files, 'Initial project setup');

      if (!commitResult.success) return commitResult;
      return { success: true, url: repoResult.url, repoName: repoResult.fullName };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

module.exports = new GitHubAutomation();
