/**
 * Commands Handler
 * All bot commands and message handling
 */

const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');
const config = require('../config');
const ai = require('../ai');
const memory = require('../memory');
const github = require('../github');
const browser = require('../browser');

class CommandHandler {
  constructor() {
    this.userStates = new Map();
  }

  async register(bot) {
    bot.start((ctx) => this.handleStart(ctx));
    bot.help((ctx) => this.handleHelp(ctx));
    bot.command('chat', (ctx) => this.handleChat(ctx));
    bot.command('clear', (ctx) => this.handleClear(ctx));
    bot.command('github', (ctx) => this.handleGitHub(ctx));
    bot.command('browser', (ctx) => this.handleBrowser(ctx));
    bot.command('tasks', (ctx) => this.handleTasks(ctx));
    bot.command('status', (ctx) => this.handleStatus(ctx));
    bot.command('cancel', (ctx) => this.handleCancel(ctx));

    bot.on('text', (ctx) => this.handleText(ctx));

    logger.info('Commands registered');
  }

  async handleStart(ctx) {
    const name = ctx.from.first_name || 'User';
    await ctx.reply(
      `🤖 **Welcome ${name}!**\n\n` +
      `I am your AI automation assistant. I can help you with:\n\n` +
      `🧠 AI Chat - Natural conversations\n` +
      `💻 GitHub - Create repos, push code\n` +
      `🌐 Browser - Open websites, screenshots\n` +
      `📝 Files - Read/write project files\n\n` +
      `Just send me any message or use /help for commands!`,
      { parse_mode: 'Markdown' }
    );
  }

  async handleHelp(ctx) {
    await ctx.reply(
      `📚 **Commands:**\n\n` +
      `/chat <msg> - Talk to AI\n` +
      `/clear - Clear chat history\n` +
      `/github create <name> - Create repo\n` +
      `/github files <repo> - List files\n` +
      `/github read <repo> <file> - Read file\n` +
      `/browser open <url> - Open website\n` +
      `/browser screenshot - Take screenshot\n` +
      `/browser scrape <url> - Get page text\n` +
      `/tasks - View your tasks\n` +
      `/cancel - Cancel current task\n` +
      `/status - System status\n\n` +
      `Or just type naturally!`,
      { parse_mode: 'Markdown' }
    );
  }

  async handleChat(ctx) {
    const msg = ctx.message.text.replace(/^/chat\s*/, '').trim();
    if (!msg) {
      await ctx.reply('Usage: /chat <your message>');
      return;
    }
    await this.processChat(ctx, msg);
  }

  async handleText(ctx) {
    if (ctx.message.text.startsWith('/')) return;
    const userId = ctx.from.id.toString();
    const state = this.userStates.get(userId);

    if (state && state.awaitingConfirm) {
      const text = ctx.message.text.toLowerCase();
      if (text === 'yes' || text === 'y' || text === 'haan') {
        await this.executeTask(ctx, state.taskId);
      } else {
        await ctx.reply('❌ Task cancelled.');
      }
      this.userStates.delete(userId);
      return;
    }

    await this.processChat(ctx, ctx.message.text);
  }

  async processChat(ctx, message) {
    const userId = ctx.from.id.toString();
    await ctx.telegram.sendChatAction(ctx.chat.id, 'typing');

    const result = await ai.chat(userId, message);

    if (result.type === 'task') {
      this.userStates.set(userId, { awaitingConfirm: true, taskId: result.taskId });
      await ctx.reply(result.message, { parse_mode: 'Markdown' });
      await ctx.reply('Reply **yes** to execute or **no** to cancel.', { parse_mode: 'Markdown' });
      return;
    }

    const chunks = Helpers.splitMessage(result.content, config.MAX_MESSAGE_LENGTH);
    for (const chunk of chunks) {
      await ctx.reply(chunk, { parse_mode: 'Markdown' });
    }
  }

  async executeTask(ctx, taskId) {
    const userId = ctx.from.id.toString();
    const task = memory.getTask(taskId);
    if (!task) {
      await ctx.reply('❌ Task not found.');
      return;
    }

    memory.updateTask(taskId, { status: 'running' });
    await ctx.reply(`🚀 Executing: ${task.description}`);

    const results = [];
    for (let i = 0; i < task.steps.length; i++) {
      const step = task.steps[i];
      await ctx.reply(`📍 Step ${i + 1}/${task.steps.length}: ${step.action}`);
      await ctx.telegram.sendChatAction(ctx.chat.id, 'typing');

      let result = { success: false, error: 'Unknown step' };
      let retries = 0;

      while (retries < 2) {
        try {
          result = await this.executeStep(step, userId);
          if (result.success) break;
        } catch (err) {
          result = { success: false, error: err.message };
        }
        retries++;
        if (!result.success && retries < 2) {
          await ctx.reply(`⚠️ Retrying... (${retries}/2)`);
          await Helpers.sleep(2000);
        }
      }

      results.push(result);
      if (result.success) {
        await ctx.reply(`✅ ${Helpers.truncate(result.result, 500)}`);
      } else {
        await ctx.reply(`❌ ${result.error}`);
      }

      memory.updateTask(taskId, { currentStep: i + 1 });
    }

    const allSuccess = results.every(r => r.success);
    memory.updateTask(taskId, {
      status: allSuccess ? 'completed' : 'failed',
      result: JSON.stringify(results)
    });

    await ctx.reply(allSuccess ? '✅ **Task completed!**' : '⚠️ **Task finished with errors.**');
  }

  async executeStep(step, userId) {
    switch (step.tool) {
      case 'github':
        return await this.execGitHubStep(step);
      case 'browser':
        return await this.execBrowserStep(step, userId);
      case 'file':
        return await this.execFileStep(step);
      case 'ai':
      default:
        return await ai.executeStep(userId, step);
    }
  }

  async execGitHubStep(step) {
    const d = step.details || {};
    switch (step.action) {
      case 'create_repo':
        return await github.createRepository(d.name, d.description, d.isPrivate);
      case 'write_file':
        return await github.writeFile(d.repo, d.path, d.content, d.message);
      case 'read_file':
        return await github.readFile(d.repo, d.path);
      case 'list_files':
        return await github.listContents(d.repo, d.path);
      case 'commit_files':
        return await github.commitFiles(d.repo, d.files, d.message);
      default:
        return { success: false, error: `Unknown: ${step.action}` };
    }
  }

  async execBrowserStep(step, userId) {
    const d = step.details || {};
    const sessionId = `user_${userId}`;
    switch (step.action) {
      case 'navigate':
        return await browser.navigate(sessionId, d.url);
      case 'screenshot':
        return await browser.screenshot(sessionId, d.options);
      case 'get_content':
        return await browser.getContent(sessionId, d);
      case 'scrape':
        return await browser.scrape(d.url, d);
      default:
        return { success: false, error: `Unknown: ${step.action}` };
    }
  }

  async execFileStep(step) {
    const fs = require('fs');
    const path = require('path');
    const d = step.details || {};
    const basePath = path.resolve('.');

    try {
      switch (step.action) {
        case 'write_file': {
          const fp = path.join(basePath, d.path);
          fs.mkdirSync(path.dirname(fp), { recursive: true });
          fs.writeFileSync(fp, d.content);
          return { success: true, result: `File written: ${d.path}` };
        }
        case 'read_file': {
          const fp = path.join(basePath, d.path);
          const content = fs.readFileSync(fp, 'utf8');
          return { success: true, result: content };
        }
        case 'create_dir': {
          const dp = path.join(basePath, d.path);
          fs.mkdirSync(dp, { recursive: true });
          return { success: true, result: `Directory created: ${d.path}` };
        }
        default:
          return { success: false, error: `Unknown: ${step.action}` };
      }
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async handleClear(ctx) {
    memory.clearConversation(ctx.from.id.toString());
    await ctx.reply('🗑️ Chat history cleared!');
  }

  async handleGitHub(ctx) {
    const args = ctx.message.text.replace(/^/github\s*/, '').trim().split(' ');
    const cmd = args[0];

    if (!cmd) {
      await ctx.reply('Usage: /github create <name> | files <repo> | read <repo> <file>');
      return;
    }

    if (cmd === 'create') {
      const name = args[1];
      if (!name) { await ctx.reply('Usage: /github create <repo-name>'); return; }
      const result = await github.createRepository(name, args.slice(2).join(' '));
      await ctx.reply(result.success ? `✅ Repo created!\n${result.url}` : `❌ ${result.error}`);
    }
    else if (cmd === 'files') {
      const repo = args[1];
      if (!repo) { await ctx.reply('Usage: /github files <repo>'); return; }
      const result = await github.listContents(repo, args[2] || '');
      if (result.success) {
        let text = `📁 **${repo}**\n\n`;
        result.items.forEach(i => { text += `${i.type === 'dir' ? '📂' : '📄'} ${i.name}\n`; });
        await ctx.reply(text, { parse_mode: 'Markdown' });
      } else {
        await ctx.reply(`❌ ${result.error}`);
      }
    }
    else if (cmd === 'read') {
      const repo = args[1], file = args[2];
      if (!repo || !file) { await ctx.reply('Usage: /github read <repo> <file>'); return; }
      const result = await github.readFile(repo, file);
      if (result.success) {
        const chunks = Helpers.splitMessage(result.content, 4000);
        for (const c of chunks) await ctx.reply(`
\`\`\`\n${c}\n\`\`\``);
      } else {
        await ctx.reply(`❌ ${result.error}`);
      }
    }
    else {
      await ctx.reply('Commands: create, files, read');
    }
  }

  async handleBrowser(ctx) {
    const args = ctx.message.text.replace(/^/browser\s*/, '').trim().split(' ');
    const cmd = args[0];
    const userId = ctx.from.id.toString();
    const sessionId = `user_${userId}`;

    if (!cmd) {
      await ctx.reply('Usage: /browser open <url> | screenshot | scrape <url>');
      return;
    }

    if (cmd === 'open') {
      const url = args[1];
      if (!url || !Helpers.isValidUrl(url)) { await ctx.reply('Valid URL required'); return; }
      await ctx.reply(`🌐 Opening ${url}...`);
      const result = await browser.navigate(sessionId, url);
      await ctx.reply(result.success ? `✅ ${result.title}\n${result.url}` : `❌ ${result.error}`);
    }
    else if (cmd === 'screenshot') {
      await ctx.reply('📸 Taking screenshot...');
      const result = await browser.screenshot(sessionId, { fullPage: true });
      if (result.success) {
        await ctx.replyWithPhoto({ source: result.filepath });
      } else {
        await ctx.reply(`❌ ${result.error}`);
      }
    }
    else if (cmd === 'scrape') {
      const url = args[1];
      if (!url || !Helpers.isValidUrl(url)) { await ctx.reply('Valid URL required'); return; }
      await ctx.reply(`🔍 Scraping ${url}...`);
      const result = await browser.scrape(url, { screenshot: true });
      if (result.success) {
        await ctx.reply(`**${result.title}**\n\n${Helpers.truncate(result.content, 3000)}`, { parse_mode: 'Markdown' });
        if (result.screenshot) await ctx.replyWithPhoto({ source: result.screenshot });
      } else {
        await ctx.reply(`❌ ${result.error}`);
      }
    }
    else {
      await ctx.reply('Commands: open, screenshot, scrape');
    }
  }

  async handleTasks(ctx) {
    const userId = ctx.from.id.toString();
    const tasks = memory.getUserTasks(userId);
    if (!tasks.length) { await ctx.reply('📋 No tasks.'); return; }
    let text = '📋 **Your Tasks:**\n\n';
    tasks.slice(-10).forEach(t => {
      const emoji = { pending: '⏳', running: '🔄', completed: '✅', failed: '❌' }[t.status] || '❓';
      text += `${emoji} ${t.description} (${t.status})\n`;
    });
    await ctx.reply(text, { parse_mode: 'Markdown' });
  }

  async handleCancel(ctx) {
    const userId = ctx.from.id.toString();
    this.userStates.delete(userId);
    await ctx.reply('✅ Cancelled.');
  }

  async handleStatus(ctx) {
    const memUsage = process.memoryUsage();
    const text =
      `📊 **Status**\n\n` +
      `🤖 Bot: Online\n` +
      `🧠 AI: ${ai.isReady() ? '✅' : '❌'}\n` +
      `💻 GitHub: ${github.isReady() ? '✅' : '❌'}\n` +
      `🌐 Browser: ${browser.isReady() ? '✅' : '❌'}\n` +
      `💾 Memory: ${(memUsage.heapUsed / 1024 / 1024).toFixed(1)} MB\n` +
      `⏱️ Uptime: ${Math.floor(process.uptime() / 60)}m`;
    await ctx.reply(text, { parse_mode: 'Markdown' });
  }
}

module.exports = new CommandHandler();
