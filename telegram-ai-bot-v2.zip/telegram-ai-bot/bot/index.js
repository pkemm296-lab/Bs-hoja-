/**
 * Bot Core - Telegraf Setup
 */

const { Telegraf } = require('telegraf');
const config = require('../config');
const logger = require('../utils/logger');

class BotCore {
  constructor() {
    this.bot = null;
  }

  async initialize() {
    try {
      if (!config.BOT_TOKEN || config.BOT_TOKEN === 'ADD_LATER') {
        logger.warn('BOT_TOKEN not set. Bot will not start.');
        return false;
      }
      this.bot = new Telegraf(config.BOT_TOKEN);
      logger.info('Bot core initialized');
      return true;
    } catch (error) {
      logger.error('Bot init failed:', error.message);
      return false;
    }
  }

  getBot() {
    return this.bot;
  }

  async start() {
    if (!this.bot) return false;
    try {
      await this.bot.launch();
      logger.info('Bot started in polling mode');
      return true;
    } catch (error) {
      logger.error('Bot start failed:', error.message);
      return false;
    }
  }

  async stop() {
    if (this.bot) {
      this.bot.stop();
      logger.info('Bot stopped');
    }
  }
}

module.exports = new BotCore();
