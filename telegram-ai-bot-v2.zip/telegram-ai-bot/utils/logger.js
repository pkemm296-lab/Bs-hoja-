/**
 * Simple File Logger
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');

class Logger {
  constructor() {
    this.logsDir = path.resolve(config.LOGS_DIR);
    this.ensureDir();
  }

  ensureDir() {
    if (!fs.existsSync(this.logsDir)) {
      fs.mkdirSync(this.logsDir, { recursive: true });
    }
  }

  getLogFile() {
    const date = new Date().toISOString().split('T')[0];
    return path.join(this.logsDir, `bot-${date}.log`);
  }

  format(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const metaStr = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
    return `[${timestamp}] [${level.toUpperCase()}]: ${message}${metaStr}\n`;
  }

  write(level, message, meta) {
    const line = this.format(level, message, meta);

    // Console output
    console.log(line.trim());

    // File output
    try {
      fs.appendFileSync(this.getLogFile(), line);
    } catch (err) {
      console.error('Failed to write log:', err.message);
    }
  }

  info(message, meta) { this.write('info', message, meta); }
  error(message, meta) { this.write('error', message, meta); }
  warn(message, meta) { this.write('warn', message, meta); }
  debug(message, meta) { 
    if (config.NODE_ENV === 'development') {
      this.write('debug', message, meta);
    }
  }
}

module.exports = new Logger();
