/**
 * Browser Automation - Playwright Only
 * Safe mode - no credential stealing
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class BrowserAutomation {
  constructor() {
    this.sessions = new Map();
    this.screenshotsDir = path.join(__dirname, '../screenshots');
    this.ready = false;
  }

  async initialize() {
    try {
      if (!fs.existsSync(this.screenshotsDir)) {
        fs.mkdirSync(this.screenshotsDir, { recursive: true });
      }
      const test = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
      await test.close();
      this.ready = true;
      logger.info('Browser automation ready (Playwright)');
      return true;
    } catch (error) {
      logger.warn('Browser init failed:', error.message);
      return false;
    }
  }

  isReady() {
    return this.ready;
  }

  async createSession(sessionId) {
    try {
      const browser = await chromium.launch({
        headless: config.BROWSER_HEADLESS,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
      const context = await browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        viewport: { width: 1920, height: 1080 }
      });
      const page = await context.newPage();
      this.sessions.set(sessionId, { browser, context, page });
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async getSession(sessionId) {
    let session = this.sessions.get(sessionId);
    if (!session) {
      const result = await this.createSession(sessionId);
      if (!result.success) return null;
      session = this.sessions.get(sessionId);
    }
    return session;
  }

  async navigate(sessionId, url) {
    try {
      const session = await this.getSession(sessionId);
      if (!session) return { success: false, error: 'No session' };
      const response = await session.page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
      return {
        success: true,
        url: session.page.url(),
        title: await session.page.title(),
        status: response?.status()
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async screenshot(sessionId, options = {}) {
    try {
      const session = await this.getSession(sessionId);
      if (!session) return { success: false, error: 'No session' };
      const filename = options.filename || `ss_${Helpers.generateId()}.png`;
      const filepath = path.join(this.screenshotsDir, filename);
      await session.page.screenshot({ path: filepath, fullPage: options.fullPage !== false });
      return { success: true, filepath, filename };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async getContent(sessionId, options = {}) {
    try {
      const session = await this.getSession(sessionId);
      if (!session) return { success: false, error: 'No session' };
      let content;
      if (options.selector) {
        content = await session.page.$eval(options.selector, el => el.innerText);
      } else {
        content = await session.page.evaluate(() => document.body.innerText);
      }
      return { success: true, content: content?.substring(0, 5000) || '' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async click(sessionId, selector) {
    try {
      const session = await this.getSession(sessionId);
      if (!session) return { success: false, error: 'No session' };
      await session.page.waitForSelector(selector, { timeout: 10000 });
      await session.page.click(selector);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async fill(sessionId, selector, value) {
    try {
      const session = await this.getSession(sessionId);
      if (!session) return { success: false, error: 'No session' };
      await session.page.waitForSelector(selector, { timeout: 10000 });
      await session.page.fill(selector, value);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async scrape(url, options = {}) {
    const sessionId = `scrape_${Helpers.generateId()}`;
    try {
      await this.createSession(sessionId);
      const nav = await this.navigate(sessionId, url);
      if (!nav.success) return nav;

      const contentResult = await this.getContent(sessionId, options);
      let screenshot = null;
      if (options.screenshot) {
        const ss = await this.screenshot(sessionId);
        screenshot = ss.success ? ss.filepath : null;
      }

      await this.closeSession(sessionId);
      return { success: true, url: nav.url, title: nav.title, content: contentResult.content, screenshot };
    } catch (error) {
      await this.closeSession(sessionId).catch(() => {});
      return { success: false, error: error.message };
    }
  }

  async closeSession(sessionId) {
    try {
      const session = this.sessions.get(sessionId);
      if (!session) return { success: true };
      await session.context.close();
      await session.browser.close();
      this.sessions.delete(sessionId);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async cleanup() {
    for (const id of this.sessions.keys()) {
      await this.closeSession(id);
    }
  }
}

module.exports = new BrowserAutomation();
